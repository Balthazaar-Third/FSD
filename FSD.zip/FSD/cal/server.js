const express = require('express');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

app.use(bodyParser.urlencoded({ extended: true }));

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/index.html');
});

app.post('/calculate', (req, res) => {
  const { num1, num2, operation } = req.body;
  let result;

  const number1 = parseFloat(num1);
  const number2 = parseFloat(num2);

  if (operation === 'add') {
    result = number1 + number2;
  } else if (operation === 'subtract') {
    result = number1 - number2;
  } else if (operation === 'multiply') {
    result = number1 * number2;
  } else if (operation === 'divide') {
    if (number2 !== 0) {
      result = number1 / number2;
    } else {
      result = 'Error: Division by zero';
    }
  }

  res.send(`
    <html>
      <head>
        <title>Calculator Result</title>
        <style>
          body { font-family: Arial, sans-serif; padding: 20px; }
          h1 { text-align: center; }
          .result { text-align: center; font-size: 20px; }
          a { text-align: center; display: block; margin-top: 20px; color: #4CAF50; text-decoration: none; font-weight: bold; }
          a:hover { text-decoration: underline; }
        </style>
      </head>
      <body>
        <h1>Calculator Result</h1>
        <div class="result">
          <p>Result: ${result}</p>
          <a href="/">Back to Calculator</a>
        </div>
      </body>
    </html>
  `);
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});




index.html


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Basic Calculator</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 20px; }
        .container { width: 300px; margin: auto; background-color: white; padding: 20px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); }
        h1 { text-align: center; }
        input { width: 100%; padding: 8px; margin: 5px 0; }
        button { width: 100%; padding: 10px; background-color: #4CAF50; color: white; border: none; font-size: 16px; cursor: pointer; }
        button:hover { background-color: #45a049; }
        select { width: 100%; padding: 8px; margin: 5px 0; }
    </style>
</head>
<body>

    <div class="container">
        <h1>Calculator</h1>
        <form action="/calculate" method="post">
            <input type="number" name="num1" placeholder="Enter first number" required>
            <input type="number" name="num2" placeholder="Enter second number" required>
            <select name="operation" required>
                <option value="add">Add</option>
                <option value="subtract">Subtract</option>
                <option value="multiply">Multiply</option>
                <option value="divide">Divide</option>
            </select>
            <button type="submit">Calculate</button>
        </form>
    </div>

</body>
</html>
