const express = require('express');
const bodyParser = require('body-parser');

const app = express();

// Middleware to parse form data
app.use(bodyParser.urlencoded({ extended: true }));

// Serve the HTML file
app.get('/', (req, res) => {
  res.sendFile(__dirname + '/index.html');
});

// Handle form submission
app.post('/bmi', (req, res) => {
  const weight = parseFloat(req.body.weight);
  const height = parseFloat(req.body.height);

  const bmi = weight / (height * height);
  
  let result = '';

  if (bmi < 18.5) {
    result = 'You are underweight.';
  } else if (bmi >= 18.5 && bmi < 24.9) {
    result = 'You have a normal weight.';
  } else if (bmi >= 25 && bmi < 29.9) {
    result = 'You are overweight.';
  } else {
    result = 'You are obese.';
  }

  res.send(`Your BMI is ${bmi.toFixed(2)}. ${result}`);
});

// Start the server
app.listen(3000, () => {
  console.log('Server is running on port 3000');
});







index.html



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>BMI Calculator</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f8ff;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
            width: 300px;
            text-align: center;
        }

        h1 {
            color: #333;
            margin-bottom: 20px;
        }

        label {
            font-weight: bold;
            display: block;
            margin: 10px 0 5px;
        }

        input {
            width: 90%;
            padding: 8px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        button {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }

        button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>

    <div class="container">
        <h1>BMI Calculator</h1>
        <form action="/bmi" method="post">
            <label for="weight">Weight (kg):</label>
            <input type="number" id="weight" name="weight" step="0.1" required>

            <label for="height">Height (m):</label>
            <input type="number" id="height" name="height" step="0.01" required>

            <button type="submit">Calculate BMI</button>
        </form>
    </div>

</body>
</html>
