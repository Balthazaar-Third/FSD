angular.module('studentApp', [])
.controller('studentController', function($scope) {
    $scope.students = [
        { name: 'Parani Dharshan', roll: '101', department: 'AI & DS' },
        { name: 'Aarav Singh', roll: '102', department: 'CSE' },
        { name: 'Meera Iyer', roll: '103', department: 'ECE' },
        { name: 'Rohit Sharma', roll: '104', department: 'IT' },
        { name: 'Lakshmi Nair', roll: '105', department: 'Mechanical' }
    ];
});



index.html


<!DOCTYPE html>
<html lang="en" ng-app="studentApp">
<head>
    <meta charset="UTF-8">
    <title>Student Information</title>
    <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.8.2/angular.min.js"></script>
    <script src="server.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
            background-color: #f7f9fa;
        }
        h1 {
            text-align: center;
            color: #333;
        }
        input {
            margin: 20px auto;
            display: block;
            padding: 8px;
            width: 50%;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        table {
            margin: 20px auto;
            width: 80%;
            border-collapse: collapse;
        }
        th, td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: center;
        }
        th {
            background-color: #4CAF50;
            color: white;
        }
        tr:hover {
            background-color: #f1f1f1;
        }
    </style>
</head>
<body ng-controller="studentController">

    <h1>Student Information</h1>

    <input type="text" ng-model="searchText" placeholder="Search by Name or Department">

    <table>
        <thead>
            <tr>
                <th>Name</th>
                <th>Roll Number</th>
                <th>Department</th>
            </tr>
        </thead>
        <tbody>
            <tr ng-repeat="student in students | filter:searchText">
                <td>{{student.name}}</td>
                <td>{{student.roll}}</td>
                <td>{{student.department}}</td>
            </tr>
        </tbody>
    </table>

</body>
</html>
