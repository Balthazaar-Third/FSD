<!DOCTYPE html>
<html ng-app="factorialApp">
<head>
  <title>Factorial Calculator</title>
  <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.8.2/angular.min.js"></script>
</head>
<body ng-controller="FactorialController" style="text-align:center; margin-top:50px;">

  <h2>Factorial Calculator (AngularJS)</h2>

  <input type="number" ng-model="number" placeholder="Enter a number">
  <button ng-click="calculateFactorial()">Calculate</button>

  <p ng-if="result !== null">Factorial: {{ result }}</p>

  <script>
    angular.module('factorialApp', [])
      .controller('FactorialController', function($scope) {
        $scope.number = 0;
        $scope.result = null;

        $scope.calculateFactorial = function() {
          let num = $scope.number;
          if (num < 0) {
            $scope.result = "Invalid input";
            return;
          }

          let fact = 1;
          for (let i = 1; i <= num; i++) {
            fact *= i;
          }

          $scope.result = fact;
        };
      });
  </script>
</body>
</html>