const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const port = 3000;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'views')));

let surveys = [];

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'index.html'));
});

app.post('/submit', (req, res) => {
  const { name, department, feedback } = req.body;

  if (!name || !department || !feedback) {
    return res.status(400).send('All fields are required!');
  }

  if (feedback.length < 10) {
    return res.status(400).send('Feedback must be at least 10 characters long!');
  }

  const survey = { name, department, feedback };
  surveys.push(survey);

  res.redirect('/surveys');
});

app.get('/surveys', (req, res) => {
  let surveyList = surveys.map((s, index) => `
    <li>
      <strong>${index + 1}. ${s.name}</strong> 
      (<em>${s.department}</em>)<br> 
      "${s.feedback}"
    </li>
  `).join('');

  res.send(`
    <html>
      <head>
        <title>Employee Surveys</title>
        <style>
          body {
            font-family: Arial, sans-serif;
            background-color: #eef2f3;
            padding: 20px;
          }
          h1 {
            text-align: center;
            color: #222;
          }
          ul {
            list-style-type: none;
            padding: 0;
          }
          li {
            background: white;
            padding: 15px;
            margin: 10px 0;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
          }
          a {
            display: block;
            text-align: center;
            margin-top: 20px;
            color: #4CAF50;
            text-decoration: none;
            font-weight: bold;
          }
          a:hover {
            text-decoration: underline;
          }
        </style>
      </head>
      <body>
        <h1>Employee Surveys</h1>
        <ul>${surveyList}</ul>
        <a href="/">Back to Survey Form</a>
      </body>
    </html>
  `);
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});





index.html


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Employee Survey</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f9f9f9;
      margin: 0;
      padding: 20px;
    }
    h1 {
      text-align: center;
      color: #333;
    }
    form {
      background-color: #fff;
      max-width: 500px;
      margin: 30px auto;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    }
    label {
      font-weight: bold;
      display: block;
      margin-top: 15px;
    }
    input[type="text"],
    textarea {
      width: 100%;
      padding: 10px;
      margin-top: 5px;
      border: 1px solid #ccc;
      border-radius: 5px;
      box-sizing: border-box;
    }
    textarea {
      resize: vertical;
      height: 100px;
    }
    button {
      margin-top: 20px;
      width: 100%;
      padding: 10px;
      background-color: #4CAF50;
      color: white;
      font-size: 16px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }
    button:hover {
      background-color: #45a049;
    }
  </style>
</head>
<body>
  <h1>Employee Survey Form</h1>
  <form action="/submit" method="POST">
    <label>Name:</label>
    <input type="text" name="name" required>

    <label>Department:</label>
    <input type="text" name="department" required>

    <label>Feedback:</label>
    <textarea name="feedback" required></textarea>

    <button type="submit">Submit Survey</button>
  </form>
</body>
</html>
