const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const port = 3000;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'views')));

let votes = { optionA: 0, optionB: 0, optionC: 0 };
let totalVotes = 0;
const maxVotes = 5;

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'index.html'));
});

app.post('/vote', (req, res) => {
  const { option } = req.body;

  if (totalVotes < maxVotes) {
    if (option && votes.hasOwnProperty(option)) {
      votes[option]++;
      totalVotes++;
    }
    if (totalVotes === maxVotes) {
      res.redirect('/results');
    } else {
      res.redirect('/');
    }
  } else {
    res.redirect('/results');
  }
});

app.get('/results', (req, res) => {
  let winner = '';
  let maxVotesCount = 0;
  
  for (let option in votes) {
    if (votes[option] > maxVotesCount) {
      maxVotesCount = votes[option];
      winner = option;
    }
  }

  res.send(`
    <html>
      <head>
        <title>Voting Results</title>
        <style>
          body { font-family: Arial, sans-serif; background: #f4f4f4; text-align: center; padding: 30px; }
          .result { background: white; padding: 20px; margin: 10px auto; width: 300px; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
          a { text-decoration: none; color: #4CAF50; font-weight: bold; display: block; margin-top: 20px; }
        </style>
      </head>
      <body>
        <h1>Voting Results</h1>
        <div class="result">
          <p>Option A: ${votes.optionA}</p>
          <p>Option B: ${votes.optionB}</p>
          <p>Option C: ${votes.optionC}</p>
          <p><strong>Winner: ${winner}</strong></p>
          <a href="/">Back to Vote</a>
          <a href="/reset">Reset Voting</a>
        </div>
      </body>
    </html>
  `);
});

app.get('/reset', (req, res) => {
  votes = { optionA: 0, optionB: 0, optionC: 0 };
  totalVotes = 0;
  res.redirect('/');
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});



views/index.html


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Live Voting System</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #eef2f3;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            text-align: center;
        }
        h1 {
            color: #333;
            margin-bottom: 20px;
        }
        button {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            font-size: 16px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background-color: #45a049;
        }
        a {
            display: block;
            margin-top: 20px;
            color: #4CAF50;
            font-weight: bold;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Vote for Your Favorite Option</h1>
    <form action="/vote" method="post">
        <button type="submit" name="option" value="optionA">Option A</button><br>
        <button type="submit" name="option" value="optionB">Option B</button><br>
        <button type="submit" name="option" value="optionC">Option C</button>
    </form>
    <a href="/results">View Results</a>
</div>

</body>
</html>
