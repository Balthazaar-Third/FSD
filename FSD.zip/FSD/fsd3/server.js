var app = angular.module('todoApp', []);

app.controller('TodoController', function($scope) {
    $scope.tasks = [];

    $scope.addTask = function() {
        if ($scope.newTask) {
            $scope.tasks.push({ name: $scope.newTask, completed: false, isEditing: false });
            $scope.newTask = "";
        }
    };

    $scope.deleteTask = function(index) {
        $scope.tasks.splice(index, 1);
    };

    $scope.completedTasks = function() {
        return $scope.tasks.filter(task => task.completed).length;
    };

    $scope.editTask = function(task) {
        task.isEditing = true;
    };

    $scope.saveTask = function(task) {
        task.isEditing = false;
    };
});


<--index.html-->

<!DOCTYPE html>
<html lang="en" ng-app="todoApp">
<head>
    <meta charset="UTF-8">
    <title>AngularJS To-Do List</title>
    <link rel="stylesheet" href="style.css">
    <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.8.2/angular.min.js"></script>
    <script src="server.js"></script>
</head>
<body>

<div class="container" ng-controller="TodoController">
    <h1>My To-Do List</h1>

    <div class="input-section">
        <input type="text" ng-model="newTask" placeholder="Add new task" />
        <button ng-click="addTask()">Add</button>
    </div>

    <ul>
        <li ng-repeat="task in tasks">
            <input type="checkbox" ng-model="task.completed"> 
            <span ng-if="!task.isEditing" ng-class="{'completed': task.completed}">{{task.name}}</span>
            <input ng-if="task.isEditing" type="text" ng-model="task.name" placeholder="Edit task">
            <button ng-if="!task.isEditing" ng-click="editTask(task)">Edit</button>
            <button ng-if="task.isEditing" ng-click="saveTask(task)">Save</button>
            <button class="delete" ng-click="deleteTask($index)">Delete</button>
        </li>
    </ul>

    <div class="footer">
        <p>Total Tasks: {{tasks.length}}</p>
        <p>Completed: {{completedTasks()}}</p>
    </div>
</div>

</body>
</html>


<--style.css-->

body {
    font-family: Arial, sans-serif;
    background: #f2f2f2;
    display: flex;
    justify-content: center;
    align-items: flex-start;
    padding: 50px;
}

.container {
    background: #fff;
    padding: 30px;
    width: 400px;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0,0,0,0.1);
}

h1 {
    text-align: center;
    color: #333;
}

.input-section {
    display: flex;
    margin-bottom: 20px;
}

.input-section input {
    flex: 1;
    padding: 10px;
    font-size: 16px;
    border-radius: 4px;
    border: 1px solid #ccc;
}

.input-section button {
    padding: 10px;
    margin-left: 5px;
    background: #28a745;
    color: white;
    border: none;
    cursor: pointer;
    border-radius: 4px;
}

ul {
    list-style: none;
    padding: 0;
}

li {
    display: flex;
    align-items: center;
    margin-bottom: 10px;
}

li span {
    flex: 1;
    margin-left: 10px;
}

li span.completed {
    text-decoration: line-through;
    color: gray;
}

button.delete {
    background: #dc3545;
    border: none;
    color: white;
    padding: 5px 10px;
    cursor: pointer;
    border-radius: 4px;
}

button.edit {
    background: #007bff;
    border: none;
    color: white;
    padding: 5px 10px;
    cursor: pointer;
    border-radius: 4px;
    margin-left: 5px;
}

button.save {
    background: #28a745;
    border: none;
    color: white;
    padding: 5px 10px;
    cursor: pointer;
    border-radius: 4px;
    margin-left: 5px;
}

li input[type="text"] {
    flex: 1;
    padding: 10px;
    font-size: 16px;
    border-radius: 4px;
    border: 1px solid #ccc;
}

.footer {
    margin-top: 20px;
    text-align: center;
    font-size: 14px;
}

