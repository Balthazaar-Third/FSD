$(document).ready(function() {
    let questions = [
        {
            question: "What is the capital of France?",
            options: ["Berlin", "London", "Paris", "Madrid"],
            answer: 2
        },
        {
            question: "Which language is used for web apps?",
            options: ["Python", "PHP", "Javascript", "All"],
            answer: 3
        },
        {
            question: "Who is the founder of Microsoft?",
            options: ["Steve Jobs", "Bill Gates", "Mark Zuckerberg", "Elon Musk"],
            answer: 1
        },
        {
            question: "Which year was JavaScript created?",
            options: ["1995", "2000", "1989", "1998"],
            answer: 0
        },
        {
            question: "HTML stands for?",
            options: ["Hyper Trainer Marking Language", "Hyper Text Marketing Language", "Hyper Text Markup Language", "Hyper Text Markup Leveler"],
            answer: 2
        }
    ];

    let currentQuestion = 0;
    let score = 0;

    function loadQuestion() {
        let q = questions[currentQuestion];
        $("#question").text(q.question);
        $("#options").empty();
        $.each(q.options, function(index, option) {
            $("#options").append(`<li data-index="${index}">${option}</li>`);
        });
    }

    loadQuestion();

    $("#options").on('click', 'li', function() {
        $("#options li").removeClass('selected');
        $(this).addClass('selected');
    });

    $("#next").click(function() {
        let selectedOption = $("li.selected").data("index");

        if (selectedOption === undefined) {
            alert("Please select an option!");
            return;
        }

        if (selectedOption == questions[currentQuestion].answer) {
            score++;
        }

        currentQuestion++;

        if (currentQuestion < questions.length) {
            loadQuestion();
        } else {
            $(".quiz-container").hide();
            $(".result").show();
            $("#score").text(score);
            $("#total").text(questions.length);
        }
    });

    $("#restart").click(function() {
        currentQuestion = 0;
        score = 0;
        $(".result").hide();
        $(".quiz-container").show();
        loadQuestion();
    });
});



#index.html


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Quiz Application</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="quiz-container">
    <h2 id="question">Question text</h2>
    <ul id="options">
        <!-- Options will appear here -->
    </ul>
    <button id="next">Next</button>
</div>

<div class="result" style="display:none;">
    <h2>Your Score: <span id="score"></span>/<span id="total"></span></h2>
    <button id="restart">Restart Quiz</button>
</div>

<!-- jQuery CDN -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="server.js"></script>

</body>
</html>



#style.css

body {
    font-family: Arial, sans-serif;
    background: #f0f2f5;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    margin: 0;
}

.quiz-container, .result {
    background: #fff;
    padding: 30px;
    border-radius: 10px;
    width: 400px;
    box-shadow: 0 0 10px rgba(0,0,0,0.1);
    text-align: center;
}

ul {
    list-style: none;
    padding: 0;
}

li {
    background: #eee;
    margin: 10px 0;
    padding: 10px;
    border-radius: 5px;
    cursor: pointer;
}

li:hover {
    background: #ddd;
}

li.selected {
    background: #4caf50;
    color: white;
}

#next, #restart {
    margin-top: 20px;
    padding: 10px 20px;
    background: #4caf50;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
}

#next:hover, #restart:hover {
    background: #45a049;
}



